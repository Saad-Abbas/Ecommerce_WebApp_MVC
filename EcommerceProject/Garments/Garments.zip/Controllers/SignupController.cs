﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Garments.Models;

namespace Garments.Controllers
{
   
    public class SignupController : Controller
    {
        signup_cls sign;
        public string value = "";
        // GET: Signup
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddSignup()
        {           

            return View();
        }
        //create signup account
        [HttpPost]
        public ActionResult signup(signup_cls signup)
        {
            if (signup.signuppassword == signup.signuprepassword)
            {
                sign.ADD(signup);                    
                value = "Successfully Account Created";
            }
            else if (signup.signuppassword != signup.signuprepassword)
            {
                value = "Both Passwords are Different /n Enter Again";
            }
            var result = value;
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}