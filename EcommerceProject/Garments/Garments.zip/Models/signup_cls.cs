﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Garments.Models
{
    public class signup_cls
    {
        public string signupname { get; set; }

        public string signupemail { get; set; }

        public string signuppassword { get; set; }

        public string signuprepassword { get; set; }

        public string usertype { get; set; }        //data from which mart : name   like chaseup



        public void ADD(signup_cls signupdata)
        {

            string query = "INSERT INTO tbl_signup([signupname],[signupemail],[signuppassword],[signuprepassword],[usertype])VALUES('" + signupdata.signupname + "','" + signupdata.signupemail + "','" + signupdata.signuppassword + "','" + signupdata.signuprepassword + "','" + signupdata.usertype + "') ";
            SqlCommand SC = new SqlCommand(query, Connection_cls.Get());
            SC.ExecuteNonQuery();

        }
    }
}